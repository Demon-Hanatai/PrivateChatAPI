﻿namespace PrivateChatApi.Models.Auth
{
    public class Registration
    {
        public string username { get; set; }
        public string password { get; set; }
        public string email { get; set; }
        public string phone { get; set; }
    }
}
