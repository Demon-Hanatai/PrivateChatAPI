﻿namespace PrivateChatApi.Models.UserModel.Friends
{
    public class PendingFriendsRequest : FriendsRequest
    {
    }
}
