﻿namespace PrivateChatApi.Models.UserModel.Friends
{
    public class FriendsRequest
    {
        public int Id { get; set; } = 0;
        public string Name { get; set; }
        public string FriendId { get; set; }
        public DateTime DateTime { get; set; }



    }
}
