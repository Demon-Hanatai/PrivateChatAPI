$date = Get-Service
$name = $date
