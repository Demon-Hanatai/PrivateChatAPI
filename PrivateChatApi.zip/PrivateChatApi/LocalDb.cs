﻿using PrivateChatApi.Models.UserModel;

namespace PrivateChatApi
{
    public class LocalDb
    {
        public static List<Authentication> users = new List<Authentication>();
    }
}
